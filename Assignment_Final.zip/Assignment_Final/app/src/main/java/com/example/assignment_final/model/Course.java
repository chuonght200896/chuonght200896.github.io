package com.example.assignment_final.model;

public class Course {
    private  Integer ID;
    private  String name;
    private  String date;
    private  Integer money;
    private  Integer lesson;

    public Course(Integer ID, String name, String date, Integer money, Integer lesson) {
        this.ID = ID;
        this.name = name;
        this.date = date;
        this.money = money;
        this.lesson = lesson;
    }

    public Course(String name, String date, Integer money, Integer lesson) {
        this.name = name;
        this.date = date;
        this.money = money;
        this.lesson = lesson;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        date = date;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        money = money;
    }

    public Integer getCount() {
        return lesson;
    }

    public void setCount(Integer count) {
        lesson = lesson;
    }
}
