package com.example.assignment_final.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.model.HoaDon;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class DAO_HoaDon {
    private SQLiteDatabase db;
    DbHelper dbHelper;
    HoaDon hoaDon;

    public DAO_HoaDon(Context context) {
        dbHelper = new DbHelper( context );
        db = dbHelper.getWritableDatabase();
    }

    public long insert(HoaDon item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "dateBill", item.getNgayThanhToan() );
        values.put( "courseID", item.getIDCourse() );
        values.put( "PTID", item.getIDPT() );
        values.put( "accountID", item.getAccountID() );
        return db.insert( "BILL", null, values );
    }


    public int delete(String maLoai) {
        db = dbHelper.getWritableDatabase();
        return db.delete( "BILL", "billID=?", new String[]{maLoai} );
    }

    public ArrayList<HoaDon> getUser(String sql, String...selectionArgs){
        ArrayList<HoaDon> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        String userName="All";
        hoaDon = new HoaDon(userName);
        list.add(hoaDon);
        while (!c.isAfterLast()){
            try {
                userName = c.getString( 0 );
                hoaDon = new HoaDon(userName);
                list.add(hoaDon);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }


    public List<HoaDon> get(String sql, String...selectionArgs){
        List<HoaDon> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int billID = Integer.parseInt(c.getString(0));
                String dateBill = c.getString(1);
                int courseID=c.getInt( 2 );
                int PTID=c.getInt( 3 );
                int accountID=c.getInt( 4);
                String trangThai =c.getString( 5 );
                String namePT = c.getString(6);
                String nameCourse = c.getString(7);
                int tongTien = Integer.parseInt(c.getString(8));
                int lesson = c.getInt(9);
                String dateCourse = c.getString( 10 );
                String userName = c.getString( 11 );
                HoaDon hoaDon = new HoaDon(billID, PTID,courseID,accountID,tongTien, namePT, nameCourse, dateBill,dateCourse,lesson,userName,trangThai);
                list.add(hoaDon);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }

    public List<HoaDon> getTK(String sql, String...selectionArgs){
        List<HoaDon> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                String nameCourse = c.getString(0);
                int tongTien = c.getInt(1);
                HoaDon hoaDon = new HoaDon(tongTien, nameCourse);
                list.add(hoaDon);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }



    public float getTotal(){
        int tongTien=0;
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT SUM( PT.moneyPT + COURSE.moneyCourse) as TongTien,ACCOUNT.userName" +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                "                INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid ",null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                tongTien=c.getInt( 0 );
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return tongTien;
    }
    public float getToTalByUserName(String userName){
        int tongTien=0;
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT SUM( PT.moneyPT + COURSE.moneyCourse) as TongTien,ACCOUNT.userName" +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                "                INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE ACCOUNT.userName LIKE '"+userName+"'",null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                tongTien=c.getInt( 0 );
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return tongTien;
    }


    public float getToTalByUserNameAndDate(String userName,String date1,String date2){
        int tongTien=0;
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT SUM( PT.moneyPT + COURSE.moneyCourse) as TongTien,ACCOUNT.userName" +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                "                INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE ACCOUNT.userName LIKE '"+userName+"' AND  BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"'",null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                tongTien=c.getInt( 0 );
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return tongTien;
    }
    public float getToTalByAndDate(String date1,String date2){
        int tongTien=0;
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT SUM( PT.moneyPT + COURSE.moneyCourse) as TongTien,ACCOUNT.userName" +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                "                INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE  BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"'",null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                tongTien=c.getInt( 0 );
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return tongTien;
    }
    public List<HoaDon> getBillByUserName(String userName){
        String sqlGetName = "SELECT BILL.*, PT.namePT, COURSE.nameCourse, PT.moneyPT + COURSE.moneyCourse as TongTien,COURSE.lesson,COURSE.dateCourse,ACCOUNT.userName " +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                " INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE ACCOUNT.userName LIKE '"+userName+"'";
        return get( sqlGetName );
    }

    public List<HoaDon> getBillByUserNameAndDate(String userName,String date1, String date2){
        String sqlGetName = "SELECT BILL.*, PT.namePT, COURSE.nameCourse, PT.moneyPT + COURSE.moneyCourse as TongTien,COURSE.lesson,COURSE.dateCourse,ACCOUNT.userName " +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                " INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE ACCOUNT.userName LIKE '"+userName+"' AND BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"'";
        return get( sqlGetName );
    }

    public List<HoaDon> getBill(){
        String sqlGetName = "SELECT BILL.*, PT.namePT, COURSE.nameCourse, PT.moneyPT + COURSE.moneyCourse as TongTien,COURSE.lesson,COURSE.dateCourse,ACCOUNT.userName " +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                " INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid ";
        return get( sqlGetName );
    }
    public List<HoaDon> getBillByCourse(){
        String sqlGetName = "SELECT  COURSE.nameCourse, sum(PT.moneyPT + COURSE.moneyCourse) as TongTien " +
                "FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID " +
                "INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid GROUP by BILL.courseID";
        return getTK( sqlGetName );
    }
    public List<HoaDon> getBillByCourseAndUsername(String userName){
        String sqlGetName = "SELECT  COURSE.nameCourse, sum(PT.moneyPT + COURSE.moneyCourse) as TongTien " +
                "FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID " +
                "INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE ACCOUNT.userName LIKE '"+userName+"' GROUP by BILL.courseID";
        return getTK( sqlGetName );
    }
    public List<HoaDon> getBillByCourseAndDate(String date1, String date2){
        String sqlGetName = "SELECT  COURSE.nameCourse, sum(PT.moneyPT + COURSE.moneyCourse) as TongTien " +
                "FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID " +
                "INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid  WHERE BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"' GROUP by BILL.courseID";
        return getTK( sqlGetName );
    }
    public List<HoaDon> getBillByCourseAndDateAndUsername(String userName,String date1, String date2){
        String sqlGetName = "SELECT  COURSE.nameCourse, sum(PT.moneyPT + COURSE.moneyCourse) as TongTien " +
                "FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID " +
                "INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid  WHERE BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"' AND ACCOUNT.userName LIKE '"+userName+"' GROUP by BILL.courseID";
        return getTK( sqlGetName );
    }
    public List<HoaDon> getBillAndDate(String date1, String date2){
        String sqlGetName = "SELECT BILL.*, PT.namePT, COURSE.nameCourse, PT.moneyPT + COURSE.moneyCourse as TongTien,COURSE.lesson,COURSE.dateCourse,ACCOUNT.userName " +
                " FROM BILL INNER JOIN COURSE ON BILL.CourseID=COURSE.CourseID" +
                " INNER JOIN PT ON BILL.PTID=PT.PTID " +
                "INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid WHERE BILL.dateBill BETWEEN '"+date1+"' AND '"+date2+"'";
        return get( sqlGetName );
    }

    public List<HoaDon> getUserBill(){
        String sqlGetName = "SELECT ACCOUNT.userName " +
                " FROM BILL INNER JOIN ACCOUNT ON BILL.accountid=ACCOUNT.accountid GROUP by ACCOUNT.userName ";
        return getUser( sqlGetName );
    }

}



