package com.example.assignment_final.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.model.PT;
import com.example.assignment_final.model.Schedule;

import java.util.ArrayList;
import java.util.List;


public class DAO_Schedule {
    private SQLiteDatabase db;
    DbHelper dbHelper;

    public DAO_Schedule(Context context) {
        dbHelper = new DbHelper( context );
        db = dbHelper.getWritableDatabase();
    }

    public long insert(Schedule item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "dateSchedule", item.getDateSchedule() );
        values.put( "hourSchedule", item.getHourSchedule() );
        values.put( "courseID", item.getCourseID() );
        return db.insert( "SCHEDULE", null, values );
    }

    public int update(Schedule item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "dateSchedule", item.getDateSchedule() );
        values.put( "hourSchedule", item.getHourSchedule() );
        values.put( "courseID", item.getCourseID() );
        return db.update( "SCHEDULE", values, "scheduleID=?", new String[]{String.valueOf( item.getScheduleID() )} );
    }

    public int delete(String maLoai) {
        db = dbHelper.getWritableDatabase();
        return db.delete( "SCHEDULE", "scheduleID=?", new String[]{maLoai} );
    }




    public ArrayList<Schedule> get(String sql, String...selectionArgs){
        ArrayList<Schedule> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int courseID= c.getInt( 0);
                String nameCourse = c.getString(1);
                String dateCourse = c.getString( 2 );
                int  moneyCourse= c.getInt(3);
                int lesson=c.getInt( 4 );
                String dateSchedule= c.getString( 5 );
                String hourSchedule= c.getString( 6 );
                Schedule schedule = new Schedule(nameCourse,dateCourse,lesson, dateSchedule,courseID,moneyCourse,hourSchedule);
                list.add(schedule);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }



    public ArrayList<Schedule> getSchedule(){
        String sqlPTGetAll = "SELECT COURSE.*, dateSchedule,hourSchedule  FROM SCHEDULE INNER JOIN COURSE ON SCHEDULE.CourseID=COURSE.CourseID";
        return get( sqlPTGetAll );
    }

    public ArrayList<Schedule> getScheduleByIDCourse(int IDCourse){
        String sqlPTGetAll = "SELECT COURSE.*, dateSchedule,hourSchedule  FROM SCHEDULE INNER JOIN COURSE ON SCHEDULE.CourseID=COURSE.CourseID " +
                "WHERE SCHEDULE.courseID="+IDCourse;
        return get( sqlPTGetAll );
    }
}



