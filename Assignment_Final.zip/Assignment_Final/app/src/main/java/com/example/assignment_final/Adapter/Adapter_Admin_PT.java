package com.example.assignment_final.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.DAO.DAO_PT;
import com.example.assignment_final.Dialog.BottomSheet_Add_PT;
import com.example.assignment_final.R;
import com.example.assignment_final.model.PT;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class Adapter_Admin_PT extends RecyclerView.Adapter<Adapter_Admin_PT.PTHolder> {
    public ArrayList<PT> list_PT;
    public Context context;
    public DAO_PT dao_pt;
    EditText edtTenPT,edtTien,edtMoTa;


    PT pt;
    Adapter_Admin_PT adapter_admin_pt;

    public Adapter_Admin_PT(ArrayList<PT> list_PT, Context context) {
        this.list_PT = list_PT;
        this.context = context;
    }

    public static class PTHolder extends RecyclerView.ViewHolder{
        public View view;
        public TextView tvTenPT,tvTien,tvNgaySinh,tvMoTa;
        ImageView imgDelete,imgEdit;
        CircleImageView img_row;
        public PTHolder(View view){
            super(view);
            tvTenPT= view.findViewById( R.id.tvTenPT );
            tvTien= view.findViewById( R.id.tvTien );
            tvNgaySinh= view.findViewById( R.id.tvNgaySinh );
            tvMoTa= view.findViewById( R.id.tvMoTa );
            imgDelete= view.findViewById( R.id.imgDelete );
            imgEdit= view.findViewById( R.id.imgEdit );
            img_row= view.findViewById( R.id.img_row );
        }
    }
    @NonNull
    @Override
    public Adapter_Admin_PT.PTHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_admin_pt,parent,false );
        PTHolder ptHolder= new PTHolder( view );
        return ptHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_Admin_PT.PTHolder holder, final int position) {
        holder.tvTenPT.setText( list_PT.get( position ).getName() );
        holder.tvNgaySinh.setText( list_PT.get( position ).getDate() );
        holder.tvTien.setText( list_PT.get( position ).getMoney()+" USD" );

        int Tien =  list_PT.get( position ).getMoney() ;
        DecimalFormat decimalFormat= (DecimalFormat) NumberFormat.getInstance( Locale.US);
        decimalFormat.applyPattern( "#,###,###,###" );
        final String formattedString = decimalFormat.format( Tien );

        holder.tvTien.setText(formattedString+" USD" );
        holder.tvTien.addTextChangedListener( onTextChangedListener() );

        holder.tvMoTa.setText( list_PT.get( position ).getNote() );


        if(list_PT.get( position ).getImages()!=null){
            byte[] imgView= list_PT.get( position ).getImages();
            Bitmap bitmap= BitmapFactory.decodeByteArray( imgView,0,imgView.length );
            holder.img_row.setImageBitmap( bitmap );
        }else{
            holder.img_row.setImageResource( R.drawable.user );
        }

        holder.imgDelete.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Delete");
                builder.setMessage("Ban co muon xoa "+list_PT.get( position ).getName()+ "khong?");
                builder.setCancelable(true);
                builder.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //Goi function Delete
                                dao_pt = new DAO_PT(context);
                                dao_pt.delete( list_PT.get(position).getID()+"");
                                list_PT.remove( position );
                                //ds_khoanTC.clear();
                                Toast.makeText(context, "Xóa thành công ",Toast.LENGTH_SHORT ).show();
                                notifyDataSetChanged();

                            }
                        });

                builder.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert = builder.create();
                alert.show();

            }
        } );
        holder.imgEdit.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle args = new Bundle();
                args.putString("ID", list_PT.get(position).getID()+"");
                args.putString("name", list_PT.get(position).getName()+"");
                args.putString("date", list_PT.get(position).getDate()+"");
                args.putString("money", list_PT.get(position).getMoney()+"");
                args.putString("note", list_PT.get(position).getNote());
                args.putByteArray("img", list_PT.get(position).getImages());
                BottomSheet_Add_PT bottomSheet_edit_khoanTC= new BottomSheet_Add_PT();
                bottomSheet_edit_khoanTC.setArguments( args );
                bottomSheet_edit_khoanTC.show(((AppCompatActivity) context).getSupportFragmentManager(),bottomSheet_edit_khoanTC.getTag());;

            }
        } );
    }

    private TextWatcher onTextChangedListener() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                edtTien.removeTextChangedListener(this);

                try {
                    String originalString = s.toString();

                    Long longval;
                    if (originalString.contains(",")) {
                        originalString = originalString.replaceAll(",", "");
                    }
                    longval = Long.parseLong(originalString);

                    DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance( Locale.US);
                    formatter.applyPattern("#,###,###,###");
                    String formattedString = formatter.format(longval);

                    //setting text after format to EditText
                    edtTien.setText(formattedString);
                    edtTien.setSelection(edtTien.getText().length());
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                }

                edtTien.addTextChangedListener(this);
            }
        };
    }


    @Override
    public int getItemCount() {
        return list_PT.size();
    }
}
