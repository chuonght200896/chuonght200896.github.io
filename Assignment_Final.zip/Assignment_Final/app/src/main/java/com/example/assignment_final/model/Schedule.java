package com.example.assignment_final.model;

public class Schedule {
    private String nameCourse,dateCourse,dateSchedule,hourSchedule;
    private int courseID,moneyCourse,scheduleID,lesson;

    public Schedule(String dateSchedule, int courseID,String hourSchedule) {
        this.dateSchedule = dateSchedule;
        this.courseID = courseID;
        this.hourSchedule = hourSchedule;
    }

    public Schedule(String nameCourse, String dateCourse, int lesson, String dateSchedule, int courseID, int moneyCourse,String hourSchedule) {
        this.nameCourse = nameCourse;
        this.dateCourse = dateCourse;
        this.lesson = lesson;
        this.dateSchedule = dateSchedule;
        this.courseID = courseID;
        this.moneyCourse = moneyCourse;
        this.hourSchedule = hourSchedule;
    }

    public String getHourSchedule() {
        return hourSchedule;
    }

    public void setHourSchedule(String hourSchedule) {
        this.hourSchedule = hourSchedule;
    }

    public int getScheduleID() {
        return scheduleID;
    }

    public void setScheduleID(int scheduleID) {
        this.scheduleID = scheduleID;
    }

    public String getNameCourse() {
        return nameCourse;
    }

    public void setNameCourse(String nameCourse) {
        this.nameCourse = nameCourse;
    }

    public String getDateCourse() {
        return dateCourse;
    }

    public void setDateCourse(String dateCourse) {
        this.dateCourse = dateCourse;
    }

    public int getLesson() {
        return lesson;
    }

    public void setLesson(int lesson) {
        this.lesson = lesson;
    }

    public String getDateSchedule() {
        return dateSchedule;
    }

    public void setDateSchedule(String dateSchedule) {
        this.dateSchedule = dateSchedule;
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public int getMoneyCourse() {
        return moneyCourse;
    }

    public void setMoneyCourse(int moneyCourse) {
        this.moneyCourse = moneyCourse;
    }
}
