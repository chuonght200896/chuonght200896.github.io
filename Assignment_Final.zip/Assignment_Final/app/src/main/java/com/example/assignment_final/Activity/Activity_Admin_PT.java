package com.example.assignment_final.Activity;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment_final.Adapter.Adapter_Admin_PT;
import com.example.assignment_final.DAO.DAO_PT;
import com.example.assignment_final.DAO.DAO_Schedule;
import com.example.assignment_final.R;
import com.example.assignment_final.model.HoaDon;
import com.example.assignment_final.model.PT;
import com.example.assignment_final.model.Schedule;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class Activity_Admin_PT extends AppCompatActivity {
    private static final int GALLER_ACTION_PICK_CODE = 100;
    public static FloatingActionButton flPT;
    public static RecyclerView rcvPTAdmin;
    public Adapter_Admin_PT pt_adapter;
    public ArrayList<PT> list_PT;
    CircleImageView imageUser;
    EditText edtTenPT,edtTien,edtMoTa;
    TextView tvNgaySinh,tvNewItem;
    Button btnUp;
    PT pt;
    DAO_PT dao_pt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admin_pt );
        flPT=findViewById( R.id.flPT );
        flPT.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog( Activity_Admin_PT.this );
            }
        } );

        rcvPTAdmin= findViewById( R.id.rcvPTAdmin );



        rcvPTAdmin.setLayoutManager( new LinearLayoutManager( this ) );
        DAO_PT ptdao= new DAO_PT( this );

        list_PT= new ArrayList<>(  );
        list_PT=ptdao.getAll();
        pt_adapter= new Adapter_Admin_PT( list_PT,this );
        rcvPTAdmin.setAdapter( pt_adapter );
    }


    public void openDialog(final Context context){
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog( context );
        bottomSheetDialog.setContentView( R.layout.bottom_sheet_edit_pt );
        edtTenPT= bottomSheetDialog.findViewById( R.id.edtTenPT );
        edtTien  = bottomSheetDialog.findViewById( R.id.edtTien );
        edtMoTa  = bottomSheetDialog.findViewById( R.id.edtMoTa);
        tvNgaySinh   = bottomSheetDialog.findViewById( R.id.tvNgaySinh);
        btnUp  = bottomSheetDialog.findViewById( R.id.btnAdd );
        tvNewItem=bottomSheetDialog.findViewById( R.id.tvNewItem );
        imageUser = bottomSheetDialog.findViewById( R.id.imgUserAdmin );
        tvNewItem.setText( "THÊM PT" );

        imageUser.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                runTimePermission();
            }
        });

        Date today= new Date(  );
        final Calendar calendar=Calendar.getInstance();
        calendar.setTime( today );

        final int dayOfWeek= calendar.get(Calendar.DAY_OF_WEEK);
        final int month= calendar.get(Calendar.MONTH);
        final int year= calendar.get(Calendar.YEAR);
        tvNgaySinh.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatePickerDialog datePickerDialog= new DatePickerDialog( context, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        SimpleDateFormat simpleDateFormat= new SimpleDateFormat( "yyyy/MM/dd" );
                        calendar.set( i,i1,i2 );
                        tvNgaySinh.setText( simpleDateFormat.format( calendar.getTime() ) );

                    }
                }, year,month,dayOfWeek);
                datePickerDialog.show();
            }
        } );

        bottomSheetDialog.show();

        btnUp.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    pt = new PT();
                    pt.setName( edtTenPT.getText().toString() );
                    pt.setMoney( Integer.valueOf( edtTien.getText().toString() ) );
                    pt.setNote( edtMoTa.getText().toString() );
                    pt.setDate( tvNgaySinh.getText().toString() );
                    pt.setImages( imageViewToByte( imageUser ) );
                    dao_pt = new DAO_PT( context );
                    dao_pt.insert( pt );
                    capNhat();

                    Toast.makeText( context, "Thêm PT thành công!", Toast.LENGTH_SHORT ).show();
                    bottomSheetDialog.dismiss();

                }catch (Exception e){
                    Toast.makeText( Activity_Admin_PT.this, "Bạn chưa nhập đủ thông tin!!!", Toast.LENGTH_SHORT ).show();
                }
            }
        } );
    }
    public void capNhat(){
        list_PT = dao_pt.getAll( );
        pt_adapter= new Adapter_Admin_PT(list_PT, Activity_Admin_PT.this);
        rcvPTAdmin.setAdapter(pt_adapter);
        pt_adapter.notifyDataSetChanged();
    }

    public void runTimePermission(){
        Dexter.withContext(Activity_Admin_PT.this).withPermission( Manifest.permission.READ_EXTERNAL_STORAGE).withListener( new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                galleryIntent();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

            }

            @Override
            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }
    //Pick Image From Gallery
    private void galleryIntent() {
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i,GALLER_ACTION_PICK_CODE);
    }
    //Convert Bitmap To Byte
    public static byte[] imageViewToByte(ImageView image) {
        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        bitmap = getResizedBitmap(bitmap,1024);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }


    public static Bitmap getResizedBitmap(Bitmap bitmap, int maxSize) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float bitmapRatio = (float) width / height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(bitmap, width, height, true);
    }

    //Convert Byte To BitMap
    public static Bitmap convertCompressedByteArrayToBitmap(byte[] src){
        return BitmapFactory.decodeByteArray(src, 0, src.length);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK){
            if(requestCode == GALLER_ACTION_PICK_CODE){
                Uri imageUri = data.getData();
                imageUser.setImageURI(imageUri);
            }
        }
    }
}
