package com.example.assignment_final.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.Adapter.Adapter_User_PT;
import com.example.assignment_final.DAO.DAO_PT;
import com.example.assignment_final.R;
import com.example.assignment_final.model.PT;

import java.util.ArrayList;

public class Activity_User_PT extends AppCompatActivity {
    RecyclerView rcvPTUser;
    public Adapter_User_PT pt_adapter;
    public ArrayList<PT> list_PT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_user_pt );
        rcvPTUser= findViewById( R.id.rcvPTUser );

        rcvPTUser.setLayoutManager( new LinearLayoutManager( this ) );
        DAO_PT ptdao= new DAO_PT( this );

        list_PT= new ArrayList<>(  );
        list_PT=ptdao.getAll();
        pt_adapter= new Adapter_User_PT( list_PT,this );
        rcvPTUser.setAdapter( pt_adapter );
    }
}