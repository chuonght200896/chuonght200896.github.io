package com.example.assignment_final.model;

public class News {
    public String title;
    public String link;
    public String image;
    public String pubDate;

    public News(String title, String link, String image, String pubDate) {
        this.title = title;
        this.link = link;
        this.image = image;
        this.pubDate = pubDate;
    }
}
