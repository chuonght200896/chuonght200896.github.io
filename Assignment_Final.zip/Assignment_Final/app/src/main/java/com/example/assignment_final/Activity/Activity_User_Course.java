package com.example.assignment_final.Activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment_final.R;
import com.example.assignment_final.fragment.Fragment_User_Course;
import com.example.assignment_final.fragment.Fragment_User_MyCourse;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Activity_User_Course extends AppCompatActivity {
    RecyclerView rcvUserCourse;
    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_user_course );
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_course);
        if (savedInstanceState == null){
            loadFragment(new Fragment_User_Course());
        }
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment;
                switch (item.getItemId()) {
                    case R.id.botCourse:
                        fragment = new Fragment_User_Course();
                        loadFragment(fragment);
                        break;
                    case R.id.botMyCourse:
                        fragment = new Fragment_User_MyCourse();
                        loadFragment(fragment);
                        break;
                }
                return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = this.getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(
                        android.R.anim.slide_in_left,  // enter
                        R.anim.fadeout,  // exit
                        R.anim.fadein,   // popEnter
                        android.R.anim.slide_out_right);
        transaction.replace(R.id.fr_, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    @Override
    public void onBackPressed() {
        finish();
    }

}
