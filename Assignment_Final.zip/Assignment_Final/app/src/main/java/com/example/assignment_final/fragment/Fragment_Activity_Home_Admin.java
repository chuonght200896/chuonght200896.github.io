package com.example.assignment_final.fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.example.assignment_final.Activity.Activity_Admin_Bill;
import com.example.assignment_final.Activity.Activity_Admin_Course;
import com.example.assignment_final.Activity.Activity_Admin_NEWS;
import com.example.assignment_final.Activity.Activity_Admin_PT;
import com.example.assignment_final.Activity.Activity_Admin_Users;
import com.example.assignment_final.Activity.Activity_User_Info;
import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_User;
import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class Fragment_Activity_Home_Admin extends Fragment {
    ImageView imgCourse,imgPT,imgNEWS,imgUser,imgBill;
    TextView tvTaiKhoan,tvNameAD;
    DAO_HoaDon dao_hoaDon;
    DAO_User dao_user;
    DbHelper dbHelper;
    public static CircleImageView imgAvarta;
    LinearLayout layoutTOP;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(  R.layout.fragment_admin_home, container, false );
        imgCourse= view.findViewById( R.id.imgCourse );
        imgPT= view.findViewById( R.id.imgTOP );
        imgUser= view.findViewById( R.id.imgUser );
        imgNEWS= view.findViewById( R.id.imgNews );
        imgBill= view.findViewById( R.id.imgBill );
        tvNameAD= view.findViewById( R.id.tvNameAD );
        tvTaiKhoan= view.findViewById( R.id.tvTaiKhoan );
        layoutTOP= view.findViewById( R.id.layoutTOP );
        imgAvarta= view.findViewById( R.id.imgAvarta );

        dao_hoaDon = new DAO_HoaDon( getContext() );
        dao_user = new DAO_User( getContext() );

        if(dao_user.getUser( dbHelper.IDuser ).get( 0 ).getImages()!=null){
            byte[] imgView= dao_user.getUser( dbHelper.IDuser ).get( 0 ).getImages();
            Bitmap bitmap= BitmapFactory.decodeByteArray( imgView,0,imgView.length );
            imgAvarta.setImageBitmap( bitmap );
        }else{
            imgAvarta.setImageResource( R.drawable.user1 );
        }

        tvTaiKhoan.setText(dao_hoaDon.getTotal()+" USD"  );
        tvNameAD.setText( dao_user.getNameAD() );
        dbHelper= new DbHelper( getContext() );
        Toast.makeText( getContext(), ""+dbHelper.Username, Toast.LENGTH_SHORT ).show();
        imgCourse.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCourse = new Intent( getContext(), Activity_Admin_Course.class);
                startActivity( intentCourse );
            }
        } );
        imgPT.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentPT = new Intent(  getContext(), Activity_Admin_PT.class);
                startActivity( intentPT );
            }
        } );
        imgNEWS.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentNEWS = new Intent(  getContext(), Activity_Admin_NEWS.class);
                startActivity( intentNEWS );
            }
        } );
        imgUser.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentNEWS = new Intent(  getContext(), Activity_Admin_Users.class);
                startActivity( intentNEWS );
            }
        } );
        layoutTOP.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentNEWS = new Intent(  getContext(), Activity_User_Info.class);
                startActivity( intentNEWS );
            }
        } );
        imgBill.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentNEWS = new Intent(  getContext(), Activity_Admin_Bill.class);
                startActivity( intentNEWS );
            }
        } );
        return view;
    }
}
