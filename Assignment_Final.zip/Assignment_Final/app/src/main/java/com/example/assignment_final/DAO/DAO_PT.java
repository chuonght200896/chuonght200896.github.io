package com.example.assignment_final.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.model.PT;

import java.util.ArrayList;
import java.util.List;


public class DAO_PT {
    private SQLiteDatabase db;
    DbHelper dbHelper;

    public DAO_PT(Context context) {
        dbHelper = new DbHelper( context );
        db = dbHelper.getWritableDatabase();
    }

    public long insert(PT item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "namePT", item.getName() );
        values.put( "birthDayPT", item.getDate() );
        values.put( "moneyPT", item.getMoney() );
        values.put( "notePT", item.getNote() );
        values.put( "imgPT",item.getImages() );
        return db.insert( "PT", null, values );
    }

    public int update(PT item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "namePT", item.getName() );
        values.put( "birthDayPT", item.getDate() );
        values.put( "moneyPT", item.getMoney() );
        values.put( "notePT", item.getNote() );
        values.put( "imgPT",item.getImages() );
        return db.update( "PT", values, "PTID=?", new String[]{String.valueOf( item.getID() )} );
    }

    public int delete(String maLoai) {
        db = dbHelper.getWritableDatabase();
        return db.delete( "PT", "PTID=?", new String[]{maLoai} );
    }




    public ArrayList<PT> get(String sql, String...selectionArgs){
        ArrayList<PT> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int PTID = Integer.parseInt(c.getString(0));
                String namePT = c.getString(1);
                String birthDayPT = c.getString(2);
                int moneyPT = c.getInt(3);
                String notePT = c.getString(5);
                byte[] img =c.getBlob( 4);
                PT pt = new PT(PTID, namePT, birthDayPT, moneyPT, notePT,img);
                list.add(pt);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }
    public ArrayList<PT> getTOP(String sql, String...selectionArgs){
        ArrayList<PT> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                String namePT = c.getString(0);
                int count= c.getInt( 1 );
                PT pt = new PT(count, namePT);
                list.add(pt);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }

    public ArrayList<PT> getAll() {
        ArrayList<PT> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT * FROM PT", null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int PTID = Integer.parseInt(c.getString(0));
                String namePT = c.getString(1);
                String birthDayPT = c.getString(2);
                int moneyPT = c.getInt(3);
                String notePT = c.getString(5);
                byte[] img =c.getBlob( 4);
                PT pt = new PT(PTID, namePT, birthDayPT, moneyPT, notePT,img);
                list.add(pt);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }
    public ArrayList<PT> getTOP_PT() {
        String sqlGetName = "SELECT PT.namePT,count(BILL.PTID) FROM BILL INNER JOIN PT ON BILL.PTID =PT.PTID  GROUP by PT.PTID ORDER BY(count(BILL.PTID)) DESC";
        return getTOP( sqlGetName );
    }

    public List<PT> getPT(int ID){
        String sqlPTGetAll = "SELECT * FROM PT WHERE PTID="+ID;
        return get( sqlPTGetAll );
    }
}



