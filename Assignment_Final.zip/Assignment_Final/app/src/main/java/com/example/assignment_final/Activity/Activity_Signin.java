package com.example.assignment_final.Activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import com.example.assignment_final.DAO.DAO_User;
import com.example.assignment_final.R;
import com.example.assignment_final.model.User;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.ByteArrayOutputStream;

import de.hdodenhof.circleimageview.CircleImageView;

public class Activity_Signin extends AppCompatActivity {
    private static final int GALLER_ACTION_PICK_CODE = 100;
    EditText edtUser,edtPass,edtFullName,edtAddress,edtPhoneNumber;
    Button btnDangKy;
    DAO_User userDAO;
    User user;
    CircleImageView imageUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_signup );
        edtUser= findViewById( R.id.edtUser );
        edtPass= findViewById( R.id.edtPass );
        edtFullName= findViewById( R.id.edtFullName );
        edtAddress= findViewById( R.id.edtAddress );
        edtPhoneNumber= findViewById( R.id.edtPhoneNumber );
        imageUser= findViewById( R.id.imgUser );
        btnDangKy=findViewById( R.id.btnDangKy );
        imageUser.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                runTimePermission();
            }
        });
        btnDangKy.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userDAO = new DAO_User( Activity_Signin.this );
                int count=0;
                String User = edtUser.getText().toString();
                String Pass = edtPass.getText().toString();
                String FullName = edtFullName.getText().toString();
                String Adress = edtAddress.getText().toString();
                String PhoneNumber = edtPhoneNumber.getText().toString();
                if (!User.equals( "" ) && !Pass.equals( "" ) && !FullName.equals( "" ) && !Adress.equals( "" ) && !PhoneNumber.equals( "" ) && PhoneNumber.length()==10){
                    for(int i= 0;i<userDAO.getUser(  ).size();i++){
                        if(edtUser.getText().toString().equalsIgnoreCase( userDAO.getUser().get( i ).getUsername() )){
                            count++;
                        }
                    }if(count==0) {
                        user = new User();
                        user.setUsername( User );
                        user.setPassword( Pass );
                        user.setFullName( FullName );
                        user.setAddress( Adress );
                        user.setPhoneNumber( PhoneNumber );
                        user.setImages( imageViewToByte(imageUser));
                        userDAO.insert( user );
                        Toast.makeText( Activity_Signin.this, "Thêm thành công", Toast.LENGTH_SHORT ).show();
                        Intent intentManHinhLogin = new Intent( getBaseContext(), Activity_Login.class );
                        startActivity( intentManHinhLogin );
                        overridePendingTransition( android.R.anim.slide_out_right,android.R.anim.fade_out);
                    }else{
                        edtUser.setError( "User đã tồn tại, bạn hãy chọn tên mới" );
                    }
                }else if(User.equals( "" ) || Pass.equals( "" ) || FullName.equals( "" ) || Adress.equals( "" ) || PhoneNumber.equals( "" )){
                    if(User.equals( "" )){
                        edtUser.setError( "Bạn chưa nhập User Name" );
                    }
                    if (Pass.equals( "" )){
                        edtPass.setError( "Bạn chưa nhập Password" );
                    }
                    if (FullName.equals( "" )){
                        edtFullName.setError( "Bạn chưa nhập Full Name" );
                    }
                    if (Adress.equals( "" )){
                        edtAddress.setError( "Bạn chưa nhập Address" );
                    }
                    if (PhoneNumber.equals( "" )){
                        edtPhoneNumber.setError( "Bạn chưa nhập Phone Number" );
                    }
                }else if(PhoneNumber.length()!=10){
                    edtPhoneNumber.setError( "Số điện thoại chỉ có 10 số" );
                }
            }
        } );
    }
    public  void runTimePermission(){
        Dexter.withContext(Activity_Signin.this).withPermission( Manifest.permission.READ_EXTERNAL_STORAGE).withListener( new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                galleryIntent();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {

            }

            @Override
            public void onPermissionRationaleShouldBeShown(com.karumi.dexter.listener.PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }
    //Pick Image From Gallery
    private void galleryIntent() {
        Intent i = new Intent(Intent.ACTION_PICK);
        i.setType("image/*");
        startActivityForResult(i,GALLER_ACTION_PICK_CODE);
    }
    //Convert Bitmap To Byte
    public static byte[] imageViewToByte(ImageView image) {
        Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap= getResizedBitmap( bitmap,1024 );
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
    public static Bitmap getResizedBitmap(Bitmap bitmap, int maxSize) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float bitmapRatio = (float) width / height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(bitmap, width, height, true);
    }
    //Convert Byte To BitMap
    public static Bitmap convertCompressedByteArrayToBitmap(byte[] src){
        return BitmapFactory.decodeByteArray(src, 0, src.length);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK){
            if(requestCode == GALLER_ACTION_PICK_CODE){
                Uri imageUri = data.getData();
                imageUser.setImageURI(imageUri);
            }
        }
    }
}
