package com.example.assignment_final.fragment;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.Activity.Activity_Admin_Bill;
import com.example.assignment_final.Adapter.Adapter_Sp_Admin_Bill;
import com.example.assignment_final.Adapter.Adapter_User_My_Course;
import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.R;
import com.example.assignment_final.model.HoaDon;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Fragment_Statistical extends Fragment {
    RecyclerView rcUserMyCourse;
    public Adapter_User_My_Course adapter_user_my_course;
    public ArrayList<HoaDon> list_HoaDon;
    public List<HoaDon> list_TK;
    public ArrayList<HoaDon> list_Sp_HoaDon;
    Button btn_date1, btn_date2;
    TextView tv_total,tv_date;
    Spinner spBill;
    PieChart pieChart;
    public  DAO_HoaDon dao_hoaDon;
    Adapter_Sp_Admin_Bill adapter_sp_admin_bill;
    public String userName="";
    final float[] tongTien = {0};
    ImageView imgRefresh;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_admin_bill, container, false);
        rcUserMyCourse= view.findViewById( R.id.rcvUserMyCourse );
        spBill= view.findViewById( R.id.spBill );
        btn_date1 = view.findViewById(R.id.btn_date1);
        btn_date2 = view.findViewById(R.id.btn_date2);
        tv_total = view.findViewById(R.id.tv_total);
        tv_date = view.findViewById(R.id.tv_date);
        pieChart= view.findViewById( R.id.piechart_1 );
        imgRefresh= view.findViewById( R.id.imgRefresh );
        rcUserMyCourse.setLayoutManager( new LinearLayoutManager( getContext() ) );
        dao_hoaDon= new DAO_HoaDon( getContext());



        list_Sp_HoaDon= new ArrayList<HoaDon>( dao_hoaDon.getUserBill(  ) );
        adapter_sp_admin_bill = new Adapter_Sp_Admin_Bill( getContext(),list_Sp_HoaDon );
        spBill.setAdapter( adapter_sp_admin_bill );

        list_HoaDon= (ArrayList<HoaDon>) dao_hoaDon.getBill();
        adapter_user_my_course= new Adapter_User_My_Course( getContext(),list_HoaDon);
        rcUserMyCourse.setAdapter( adapter_user_my_course );



        spBill.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                android.icu.text.DecimalFormat formatter = new DecimalFormat("#,###");
                btn_date2.setText( "To Date" );
                btn_date1.setText( "From Date" );
                if(list_Sp_HoaDon.get( i ).getNameUsser().equalsIgnoreCase( "All" )){
                    list_HoaDon= (ArrayList<HoaDon>) dao_hoaDon.getBill();
                    adapter_user_my_course= new Adapter_User_My_Course( getContext(),list_HoaDon);
                    rcUserMyCourse.setAdapter( adapter_user_my_course );
                    tv_total.setText( formatter.format( dao_hoaDon.getTotal())+" USD" );

                    ArrayList<PieEntry> yValues = new ArrayList<>();
                    userName=list_Sp_HoaDon.get( i ).getNameUsser();
                    tongTien[0]=dao_hoaDon.getTotal();
                    list_TK = dao_hoaDon.getBillByCourse();
                    for(int j=0;j<list_TK.size();j++){
                        float tiLe= (list_TK.get( j ).getTongTien()/ tongTien[0])*100;
                        yValues.add(new PieEntry( tiLe  ,list_TK.get( j ).getNameCourse()));
                    }
                    setPieChart(  );
                    setDataChart(yValues);
                    if(btn_date1.getText().equals( "From Date" )||btn_date2.getText().equals( "To Date" )){

                    }else {
                        setDataAll();
                    }
                }else{
                    list_HoaDon= (ArrayList<HoaDon>) dao_hoaDon.getBillByUserName(list_Sp_HoaDon.get( i ).getNameUsser());
                    adapter_user_my_course= new Adapter_User_My_Course( getContext(),list_HoaDon);
                    rcUserMyCourse.setAdapter( adapter_user_my_course );

                    ArrayList<PieEntry> yValues = new ArrayList<>();
                    userName=list_Sp_HoaDon.get( i ).getNameUsser();
                    tv_total.setText( formatter.format( dao_hoaDon.getToTalByUserName( userName))+" USD");
                    tongTien[0] =dao_hoaDon.getToTalByUserName( list_Sp_HoaDon.get( i ).getNameUsser());

                    list_TK = dao_hoaDon.getBillByCourseAndUsername(userName);
                    for(int j=0;j<list_TK.size();j++){
                        float tiLe= (list_TK.get( j ).getTongTien()/ tongTien[0])*100;
                        yValues.add(new PieEntry( tiLe  ,list_TK.get( j ).getNameCourse()));
                    }
                    setPieChart(  );
                    setDataChart(yValues);
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        } );
        btn_date1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date(btn_date1);
            }
        } );
        btn_date2.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Date(btn_date2);
                imgRefresh.setOnClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String date1 = btn_date1.getText().toString();
                        String date2 = btn_date2.getText().toString();
                        if (date1.equals( "From Date" ) || date2.equals( "To Date" )) {
                            Toast.makeText( getContext(), "Bạn chưa chọn ngày", Toast.LENGTH_SHORT ).show();
                        } else {
                            if (userName.equalsIgnoreCase( "All" )) {
                                ArrayList<PieEntry> yValues = new ArrayList<>();
                                setDataAll();
                                tongTien[0] = dao_hoaDon.getToTalByAndDate( date1, date2 );
                                list_TK = dao_hoaDon.getBillByCourseAndDate( date1, date2 );

                                for (int j = 0; j < list_TK.size(); j++) {
                                    float tiLe = (list_TK.get( j ).getTongTien() / tongTien[0]) * 100;
                                    yValues.add( new PieEntry( tiLe, list_TK.get( j ).getNameCourse() ) );
                                }
                                setPieChart();
                                setDataChart( yValues );
                            } else {
                                ArrayList<PieEntry> yValues = new ArrayList<>();
                                setData();
                                tongTien[0] = dao_hoaDon.getToTalByUserNameAndDate( userName, date1, date2 );
                                list_TK = dao_hoaDon.getBillByCourseAndDateAndUsername( userName, date1, date2 );

                                for (int j = 0; j < list_TK.size(); j++) {
                                    float tiLe = (list_TK.get( j ).getTongTien() / tongTien[0]) * 100;
                                    yValues.add( new PieEntry( tiLe, list_TK.get( j ).getNameCourse() ) );
                                }
                                setPieChart();
                                setDataChart( yValues );
                            }
                            tv_date.setText( date1 + " - " + date2 );
                        }
                    }
                } );

            }
        } );
        return view;
    }
    public void setPieChart(){
        pieChart.setUsePercentValues(true);
        pieChart.setDrawEntryLabels( true );
        pieChart.setHoleRadius( 20f );
        pieChart.getDescription().setEnabled(false);
        pieChart.setExtraOffsets(5,10,5,5);
        pieChart.setDragDecelerationFrictionCoef(10f);
        pieChart.setTransparentCircleRadius(30f);
        pieChart.setHoleColor( Color.WHITE);
        pieChart.getLegend().setTextColor( Color.WHITE );
        pieChart.getLegend().setOrientation( Legend.LegendOrientation.VERTICAL );
        pieChart.getLegend().setTextSize( 15f );
        pieChart.animateY(3000, Easing.EaseInOutCubic);
    }
    public void setDataChart(ArrayList yValues){
        PieDataSet dataSet = new PieDataSet(yValues, "Tỉ lệ phi thu khóa học");
        dataSet.setSliceSpace(5f);
        dataSet.setSelectionShift(0.3f);
        dataSet.setColors( ColorTemplate.COLORFUL_COLORS);
        PieData pieData = new PieData((dataSet));
        pieData.setValueTextSize(20f);
        pieData.setValueTextColor(Color.WHITE);
        pieChart.setData(pieData);
    }
    public void setDataAll(){
        DecimalFormat formatter = new DecimalFormat("#,###");
        float total_2 = dao_hoaDon.getToTalByAndDate(btn_date1.getText().toString(),btn_date2.getText().toString());
        String s = formatter.format(total_2);
        tv_total.setText("Tổng tiền: "+s+"VNĐ");

        list_HoaDon= (ArrayList<HoaDon>) dao_hoaDon.getBillAndDate(btn_date1.getText().toString(),btn_date2.getText().toString());
        adapter_user_my_course= new Adapter_User_My_Course( getContext(),list_HoaDon);
        rcUserMyCourse.setAdapter( adapter_user_my_course );
    }
    public void setData(){
        DecimalFormat formatter = new DecimalFormat("#,###");
        float total_2 = dao_hoaDon.getToTalByUserNameAndDate(userName,btn_date1.getText().toString(),btn_date2.getText().toString());
        String s = formatter.format(total_2);
        tv_total.setText("Tổng tiền: "+s+"USD");

        list_HoaDon= (ArrayList<HoaDon>) dao_hoaDon.getBillByUserNameAndDate(userName,btn_date1.getText().toString(),btn_date2.getText().toString());
        adapter_user_my_course= new Adapter_User_My_Course( getContext(),list_HoaDon);
        rcUserMyCourse.setAdapter( adapter_user_my_course );
    }
    private void Date(final Button btn){
        Date today = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(today);

        final int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        final int months = cal.get(Calendar.MONTH);
        final int years = cal.get(Calendar.YEAR);
        final Calendar calendar = Calendar.getInstance();


        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
                calendar.set(i,i1,i2);
                btn.setText(simpleDateFormat.format(calendar.getTime()));

            }
        },years,months,dayOfWeek);


        datePickerDialog.show();

    }
}
