package com.example.assignment_final.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.Adapter.Adapter_User;
import com.example.assignment_final.DAO.DAO_User;
import com.example.assignment_final.R;
import com.example.assignment_final.model.User;

import java.util.ArrayList;

public class Activity_Admin_Users extends AppCompatActivity {
    RecyclerView rcvUserAdmin;
    public Adapter_User user_adapter;
    public ArrayList<User> list_User;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admin_users );
        rcvUserAdmin= findViewById( R.id.rcvUserAdmin );

        rcvUserAdmin.setLayoutManager( new LinearLayoutManager( this ) );
        DAO_User userDAO= new DAO_User( this );

        list_User= new ArrayList<>(  );
        list_User=userDAO.getAll();
        user_adapter= new Adapter_User( list_User,this );
        rcvUserAdmin.setAdapter( user_adapter );
    }
}
