package com.example.assignment_final.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


import com.example.assignment_final.R;
import com.example.assignment_final.fragment.Fragment_Activity_Home_Admin;
import com.example.assignment_final.fragment.Fragment_Statistical;
import com.example.assignment_final.fragment.Fragment_User_News;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Activity_Admin extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_admin );
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_admin);
        if (savedInstanceState == null){
            loadFragment(new Fragment_Activity_Home_Admin());
        }
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment;
                switch (item.getItemId()) {
                    case R.id.botHome:
                        fragment = new Fragment_Activity_Home_Admin();
                        loadFragment(fragment);
                        break;
                    case R.id.botStatistical:
                        fragment = new Fragment_Statistical();
                        loadFragment(fragment);
                        break;
                }
                return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = this.getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(
                android.R.anim.slide_in_left,  // enter
                R.anim.fadeout,  // exit
                R.anim.fadein,   // popEnter
                android.R.anim.slide_out_right  // popExit
        );
        transaction.replace(R.id.fr_admin, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    @Override
    public void onBackPressed() {
        Intent intentLogin = new Intent( this, Activity_Login.class);
        startActivity( intentLogin );

        finish();
    }
}
