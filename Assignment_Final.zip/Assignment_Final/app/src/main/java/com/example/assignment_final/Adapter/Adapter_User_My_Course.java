package com.example.assignment_final.Adapter;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_Schedule;
import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.R;
import com.example.assignment_final.model.HoaDon;
import com.example.assignment_final.model.Schedule;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class Adapter_User_My_Course extends RecyclerView.Adapter<Adapter_User_My_Course.HoadonHolder> {
    public ArrayList<HoaDon> list_HoaDon;

    public ArrayList<Schedule> list_All_Schedule;
    public Context context;
    DAO_HoaDon dao_hoaDon;
    DAO_Schedule dao_schedule;
    public TextView tvTien,tvTieuDeSchedule;
    Button btnCancel;
    DbHelper dbHelper;
    RecyclerView rcvSchedule;
    Adapter_Schedule adapter_schedule;
    public int IDCourse;
    public SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
    public String date = df.format( Calendar.getInstance().getTime());
    public  Adapter_User_My_Course(Context context, ArrayList<HoaDon> list_HoaDon) {
        this.list_HoaDon = list_HoaDon;
        this.context = context;
        dao_hoaDon=new DAO_HoaDon( context );
    }

    public static class HoadonHolder extends RecyclerView.ViewHolder {
        public View view;
        public TextView tvTenKhoaHoc, tvTien, tvNgayThanhToan, tvTenPT,tvCount, tvNgayMoHoc,tvTrangThai;

        public HoadonHolder(View view) {
            super( view );
            tvTenKhoaHoc = view.findViewById( R.id.tvTenKhoaHoc );
            tvTien = view.findViewById( R.id.tvTien );
            tvNgayThanhToan = view.findViewById( R.id.tvNgayThanhToan );
            tvTenPT = view.findViewById( R.id.tvTenPT );
            tvTrangThai= view.findViewById( R.id.tvTrangThai );

            this.tvCount = view.findViewById( R.id.tvCount );
            this.tvNgayMoHoc = view.findViewById( R.id.tvNgayMoHoc );
        }
    }
    @NonNull
    @Override
    public Adapter_User_My_Course.HoadonHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_user_my_course,parent,false );
        HoadonHolder courseHolder= new HoadonHolder( view );
        return courseHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_User_My_Course.HoadonHolder holder, final int position) {
        final HoaDon hoaDon = list_HoaDon.get( position );
        String dateSchedule;

        int id;
        if(list_HoaDon!=null){
            holder.tvTenKhoaHoc.setText( hoaDon.getNameCourse() );
            holder.tvNgayThanhToan.setText( hoaDon.getNgayThanhToan() );
            holder.tvTenPT.setText( " - "+hoaDon.getNamePT() );


            int Tien =  hoaDon.getTongTien() ;
            DecimalFormat decimalFormat= (DecimalFormat) NumberFormat.getInstance( Locale.US);
            decimalFormat.applyPattern( "#,###,###,###" );
            final String formattedString = decimalFormat.format( Tien );

            holder.tvTien.setText( formattedString+" USD" );


            holder.tvCount.setText( "("+hoaDon.getCount()+"Buổi)" );
            holder.tvNgayMoHoc.setText( hoaDon.getNgayMoKhoa() );
            if(dbHelper.Username.equalsIgnoreCase( "Admin" )){

            }else {
                holder.itemView.setOnClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        IDCourse = list_HoaDon.get( position ).getIDCourse();
                        String nameCourse = list_HoaDon.get( position ).getNameCourse();
                        openDialog( context, IDCourse, nameCourse );
                    }
                } );
            }
            IDCourse = list_HoaDon.get( position ).getIDCourse();
            dao_schedule = new DAO_Schedule( context );
            list_All_Schedule=dao_schedule.getScheduleByIDCourse(IDCourse);

            if( list_All_Schedule.get( list_All_Schedule.size()-1 ).getDateSchedule().compareTo(date) <0){
                holder.tvTrangThai.setText("Đã hoàn thành"  );
                holder.tvTrangThai.setTextColor( Color.parseColor("#00FF00") );
                @SuppressLint("ResourceType") Animation animation = AnimationUtils.loadAnimation(context,R.anim.animal);
                holder.tvTrangThai.startAnimation(animation);
            }else if(list_All_Schedule.get( list_All_Schedule.size()-1 ).getDateSchedule().compareTo(date) >=0){
                if(hoaDon.getNgayMoKhoa().compareTo(date)<0){
                    holder.tvTrangThai.setText("Đang học"  );
                    holder.tvTrangThai.setTextColor( Color.parseColor("#0033FF") );
                    @SuppressLint("ResourceType") Animation animation = AnimationUtils.loadAnimation(context,R.anim.animal);
                    holder.tvTrangThai.startAnimation(animation);
                }
                if(hoaDon.getNgayMoKhoa().compareTo(date)>0){
                    holder.tvTrangThai.setText("Sắp học"  );
                    holder.tvTrangThai.setTextColor( Color.parseColor("#FFD700") );
                    @SuppressLint("ResourceType") Animation animation = AnimationUtils.loadAnimation(context,R.anim.animal);
                    holder.tvTrangThai.startAnimation(animation);
                }
            }
            Toast.makeText( context, ""+date, Toast.LENGTH_SHORT ).show();
        }

    }
    @Override
    public int getItemCount() {
        return list_HoaDon.size();
    }

    protected void openDialog(final Context context,int IDCourse,String nameCourse){
        //custom dialog
        final BottomSheetDialog dialog = new BottomSheetDialog( context );
        dialog.setContentView(R.layout.dialog_schedule);

        btnCancel = dialog.findViewById( R.id.btnCancel );
        rcvSchedule= dialog.findViewById( R.id.rcvSchedule );
        tvTieuDeSchedule=dialog.findViewById( R.id.tvTieuDeSchedule );

        tvTieuDeSchedule.setText("Lịch tập khóa học "+nameCourse);
        rcvSchedule.setLayoutManager( new LinearLayoutManager( context ) );
        DAO_Schedule dao_schedule= new DAO_Schedule( context );

        list_All_Schedule=dao_schedule.getScheduleByIDCourse(IDCourse);
        adapter_schedule= new Adapter_Schedule(list_All_Schedule, context);
        rcvSchedule.setAdapter( adapter_schedule );
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }
}
