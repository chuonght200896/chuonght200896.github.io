package com.example.assignment_final.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.R;
import com.example.assignment_final.model.User;

import java.util.ArrayList;

public class Adapter_User extends RecyclerView.Adapter<Adapter_User.UserHolder> {
    ArrayList<User> list_User;
    public Context context;

    public Adapter_User(ArrayList<User> list_User, Context context) {
        this.list_User = list_User;
        this.context = context;
    }
    public static class UserHolder extends RecyclerView.ViewHolder{
        public View view;
        public TextView tvTenNguoiDung,tvPhoneNumber,tvAddress;
        ImageView img_row;
        public UserHolder(View view){
            super(view);
            tvTenNguoiDung= view.findViewById( R.id.tvTenNguoiDung );
            tvPhoneNumber= view.findViewById( R.id.tvPhoneNumber );
            tvAddress= view.findViewById( R.id.tvAddress );
            img_row= view.findViewById( R.id.img_row );
        }
    }
    @NonNull
    @Override
    public UserHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_admin_users,parent,false );
        UserHolder userHolder= new UserHolder( view );
        return userHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull UserHolder holder, int position) {
        holder.tvTenNguoiDung.setText( list_User.get( position ).getFullName() );
        holder.tvPhoneNumber.setText( list_User.get( position ).getPhoneNumber() );
        holder.tvAddress.setText( list_User.get( position ).getAddress() );
        if(list_User.get( position ).getImages()!=null){
            byte[] imgView= list_User.get( position ).getImages();
            Bitmap bitmap= BitmapFactory.decodeByteArray( imgView,0,imgView.length );
            holder.img_row.setImageBitmap( bitmap );
        }else{
            holder.img_row.setImageResource( R.drawable.user );
        }
    }

    @Override
    public int getItemCount() {
        return list_User.size();
    }
}
