package com.example.assignment_final.model;

import androidx.annotation.NonNull;

public class PT {
    private  Integer ID,count;
    private  String Name;
    private  String Date;
    private  Integer Money;
    private  String Note;
    private byte[] images;

    public PT() {
    }

    public PT(String name, String date, Integer money, String note) {
        Name = name;
        Date = date;
        Money = money;
        Note = note;
    }


    public PT(Integer ID, String name, String date, Integer money, String note,byte[] images) {
        this.ID = ID;
        Name = name;
        Date = date;
        Money = money;
        Note = note;
        this.images= images;
    }
    public PT(Integer ID, String name, String date, Integer money, String note) {
        this.ID = ID;
        Name = name;
        Date = date;
        Money = money;
        Note = note;;
    }
    public PT(Integer ID, Integer count, String name, String date, Integer money, String note, byte[] images) {
        this.ID = ID;
        this.count = count;
        Name = name;
        Date = date;
        Money = money;
        Note = note;
        this.images = images;
    }

    public byte[] getImages() {
        return images;
    }

    public void setImages(byte[] images) {
        this.images = images;
    }

    public PT(Integer count, String name) {
        this.count = count;
        Name = name;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public Integer getMoney() {
        return Money;
    }

    public void setMoney(Integer money) {
        Money = money;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String note) {
        Note = note;
    }

    @NonNull
    @Override
    public String toString() {
        return Name;
    }
}
