package com.example.assignment_final.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import com.example.assignment_final.R;
import com.example.assignment_final.model.HoaDon;

import java.util.ArrayList;

public class Adapter_Sp_Admin_Bill extends BaseAdapter {
    Context context;
    ArrayList<HoaDon> ds_HoaDon;
    TextView tv_sp_Admin_Bill;

    public Adapter_Sp_Admin_Bill(Context context, ArrayList<HoaDon> ds_HoaDon) {
        this.context = context;
        this.ds_HoaDon = ds_HoaDon;
    }

    @Override
    public int getCount() {
        return ds_HoaDon.size();
    }

    @Override
    public Object getItem(int i) {
        return ds_HoaDon.get( i );
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = ((Activity)context).getLayoutInflater().inflate( R.layout.item_sp_admin_bill,viewGroup,false );
        tv_sp_Admin_Bill= view.findViewById( R.id.tv_sp_Admin_Bill );
        tv_sp_Admin_Bill.setText( ds_HoaDon.get( i).getNameUsser());
        return view;
    }
}
