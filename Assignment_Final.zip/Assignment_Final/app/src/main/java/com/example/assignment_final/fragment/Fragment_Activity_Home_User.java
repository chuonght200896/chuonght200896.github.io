package com.example.assignment_final.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.Activity.Activity_User_Course;
import com.example.assignment_final.Activity.Activity_User_Info;
import com.example.assignment_final.Activity.Activity_User_PT;
import com.example.assignment_final.Adapter.Adapter_TOP;
import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_PT;
import com.example.assignment_final.R;
import com.example.assignment_final.model.PT;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Fragment_Activity_Home_User  extends Fragment {
    private static final int REQUEST_CALL = 1;
    ImageView imgCourse,imgInfo,imgPT;
    public static RecyclerView rcvTOPActivityUser;
    ViewFlipper vfUser;
    Adapter_TOP top_adapter;
    TextView tvTieuDe;
    public ArrayList<PT> list_PT;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_user_home, container, false );
        imgCourse=view.findViewById( R.id.imgCourse );
        imgInfo= view.findViewById( R.id.imgInfo );
        imgPT= view.findViewById( R.id.imgTOP );
        tvTieuDe=view.findViewById( R.id.tvTieuDe );

        rcvTOPActivityUser= view.findViewById( R.id.rcvTOPActivityUser );
        vfUser=view.findViewById( R.id.vfUser );
        vfUser.setFlipInterval( 3000 );
        vfUser.setAutoStart( true );


        imgCourse.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCourse = new Intent( getContext(), Activity_User_Course.class);
                startActivity( intentCourse );
            }
        } );
        imgInfo.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCourse = new Intent( getContext(), Activity_User_Info.class);
                startActivity( intentCourse );
            }
        } );
        imgPT.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentPT = new Intent( getContext(), Activity_User_PT.class);
                startActivity( intentPT );
            }
        } );


        rcvTOPActivityUser.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        DAO_PT ptdao= new DAO_PT( getContext() );
        list_PT= new ArrayList<>(  );
        list_PT= ptdao.getTOP_PT();
        top_adapter= new Adapter_TOP( list_PT,getContext() );
        rcvTOPActivityUser.setAdapter( top_adapter );
        return view;
    }

}
