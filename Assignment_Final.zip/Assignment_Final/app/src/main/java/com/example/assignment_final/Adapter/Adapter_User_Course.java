package com.example.assignment_final.Adapter;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_Schedule;
import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.Dialog.BottomSheet_Add_Course_KH;
import com.example.assignment_final.R;
import com.example.assignment_final.model.Course;
import com.example.assignment_final.model.HoaDon;
import com.example.assignment_final.model.Schedule;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class Adapter_User_Course extends RecyclerView.Adapter<Adapter_User_Course.CourseADHolder> {
    public ArrayList<Course> list_Course;
    public List<HoaDon> list_HoaDon;
    DAO_HoaDon dao_hoaDon;
    public Context context;
    DbHelper dbHelper;

    public BottomSheet_Add_Course_KH bottomSheet_add_course_kh= new BottomSheet_Add_Course_KH();
    public TextView tvTien;
    public Adapter_User_Course(ArrayList<Course> list_Course, Context context) {
        this.list_Course = list_Course;
        this.context = context;

    }

    public static class CourseADHolder extends RecyclerView.ViewHolder{
        public View view;
        Button btnDangKy;
        public TextView tvTenKhoaHoc,tvTien,tvNgayMoHoc,tvCount;
        public CourseADHolder(View view){
            super(view);
            tvTenKhoaHoc= view.findViewById( R.id.tvTenKhoaHoc );
            tvTien= view.findViewById( R.id.tvTien );
            tvNgayMoHoc= view.findViewById( R.id.tvNgayMoHoc );
            tvCount= view.findViewById( R.id.tvCount );
            btnDangKy= view.findViewById( R.id.btnDangKy );
        }
    }
    @NonNull
    @Override
    public Adapter_User_Course.CourseADHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_user_course,parent,false );
        CourseADHolder courseHolder= new CourseADHolder( view );
        return courseHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final Adapter_User_Course.CourseADHolder holder, final int position) {
        holder.tvTenKhoaHoc.setText( list_Course.get( position ).getName() );
        holder.tvNgayMoHoc.setText( list_Course.get( position ).getDate() );
        final int[] IDCourse = {list_Course.get( position ).getID()};
        dao_hoaDon= new DAO_HoaDon( context );
        int Tien =  list_Course.get( position ).getMoney() ;
        DecimalFormat decimalFormat= (DecimalFormat) NumberFormat.getInstance( Locale.US);
        decimalFormat.applyPattern( "#,###,###,###" );
        final String formattedString = decimalFormat.format( Tien );

        holder.tvTien.setText(formattedString+" USD" );
        holder.tvTien.addTextChangedListener( onTextChangedListener() );

        holder.tvCount.setText("(" +list_Course.get( position ).getCount()+ " Buổi)" );


            holder.btnDangKy.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    list_HoaDon = dao_hoaDon.getBillByUserName( dbHelper.Username );
                    int count = 0;
                    for (int i = 0; i < list_HoaDon.size(); i++) {
                        if (IDCourse[0] == list_HoaDon.get( i ).getIDCourse()) {
                            count++;
                        }
                    }
                    if (count == 0) {
                        Bundle bundle = new Bundle();
                        bundle.putInt( "ID", list_Course.get( position ).getID() );
                        bundle.putString( "TenKhoaHoc", list_Course.get( position ).getName() );
                        bundle.putString( "NgayMoHoc", list_Course.get( position ).getDate() );
                        bundle.putInt( "Tien", list_Course.get( position ).getMoney() );
                        bundle.putInt( "Count", list_Course.get( position ).getCount() );
                        bottomSheet_add_course_kh.setArguments( bundle );
                        openDialog( context );
                    } else {
                        Toast.makeText( context, "Khóa học này bạn đã đăng ký rồi!!!", Toast.LENGTH_SHORT ).show();
                    }
                }
            } );
        }


    public void openDialog(Context context){
        bottomSheet_add_course_kh.show(((AppCompatActivity) context).getSupportFragmentManager(),bottomSheet_add_course_kh.getTag());
    }
    @Override
    public int getItemCount() {
        return list_Course.size();
    }
    private TextWatcher onTextChangedListener() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                tvTien.removeTextChangedListener(this);

                try {
                    String originalString = s.toString();

                    Long longval;
                    if (originalString.contains(",")) {
                        originalString = originalString.replaceAll(",", "");
                    }
                    longval = Long.parseLong(originalString);

                    DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance( Locale.US);
                    formatter.applyPattern("#,###,###,###");
                    String formattedString = formatter.format(longval);

                    //setting text after format to EditText
                    tvTien.setText(formattedString);
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                }

                tvTien.addTextChangedListener(this);
            }
        };
    }
}
