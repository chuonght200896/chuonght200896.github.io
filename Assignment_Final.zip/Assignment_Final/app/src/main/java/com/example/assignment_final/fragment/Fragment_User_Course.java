package com.example.assignment_final.fragment;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.assignment_final.Adapter.Adapter_User_Course;
import com.example.assignment_final.DAO.DAO_Course;
import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_Schedule;
import com.example.assignment_final.R;
import com.example.assignment_final.model.Course;
import com.example.assignment_final.model.HoaDon;
import com.example.assignment_final.model.Schedule;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;


public class Fragment_User_Course extends Fragment {
    public static FloatingActionButton flADCourse;
    RecyclerView rcUserCourse;
    public Adapter_User_Course course_adapter;
    public ArrayList<Course> list_Course;
    DAO_Schedule dao_schedule;
    public ArrayList<Schedule> list_Schedule;
    DAO_HoaDon dao_hoaDon;

    public int hourStart;
    public int hourEnd;
    public String hour;
    public Random random = new Random();
    public  String dateSchedule;
    public int id;
    Schedule schedule;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.fragment_user_course, container, false );
        rcUserCourse= view.findViewById( R.id.rcvUserCourse );

        rcUserCourse.setLayoutManager( new LinearLayoutManager( getContext() ) );
        DAO_Course courseDAO= new DAO_Course( getContext() );

        list_Course= new ArrayList<>(  );
        list_Course=courseDAO.getAll();
        course_adapter= new Adapter_User_Course( list_Course,getContext() );
        rcUserCourse.setAdapter( course_adapter );

        dao_schedule= new DAO_Schedule( getContext() );
        list_Schedule=dao_schedule.getSchedule();

        courseDAO=  new DAO_Course( getContext() );
        list_Course = courseDAO.getAll();
        if(list_Schedule.size()==0) {
            for(int i=0; i<list_Course.size();i++) {
                hourStart=7+random.nextInt(8);
                hourEnd=hourStart+2;
                hour = hourStart+"h - "+hourEnd+"h";
                String dateCourse = list_Course.get( i ).getDate();
                int day= Integer.parseInt( dateCourse.substring( 8 ) );
                int month= Integer.parseInt( dateCourse.substring( 5,7 ) );
                int year= Integer.parseInt( dateCourse.substring( 0,4 ) );
                id = list_Course.get( i ).getID();
                for (int j = 0; j < list_Course.get( i ).getCount(); j++) {
                    day += 2;
                    if (day > 30) {
                        month++;
                        day = day - 30;
                        if (month > 12) {
                            year++;
                            month = month - 12;
                        }
                    }else{
                    }
                    dao_schedule = new DAO_Schedule( getContext() );
                    if (day < 10 && month < 10) {
                        dateSchedule = year + "/0" + month + "/0" + day + "\n";
                    } else if (day < 10 && month > 10){
                        dateSchedule = year + "/" + month + "/0" + day + "\n";
                    } else if (day > 10 && month < 10) {
                        dateSchedule = year + "/0" + month + "/" + day + "\n";
                    } else {
                        dateSchedule = year + "/" + month + "/" + day + "\n";
                    }
                    schedule = new Schedule( dateSchedule, id,hour );
                    dao_schedule.insert( schedule );
                }

            }
        }


        return view;
    }


}
