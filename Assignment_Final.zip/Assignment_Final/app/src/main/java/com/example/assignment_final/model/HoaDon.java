package com.example.assignment_final.model;

public class HoaDon {
    private int maHD,IDPT,IDCourse,accountID,tongTien,count;
    private String nameUsser,namePT,nameCourse, ngayThanhToan,ngayMoKhoa,trangThai;

    public HoaDon(String nameUsser) {
        this.nameUsser = nameUsser;
    }

    public HoaDon(int maHD, int IDPT, int IDCourse, int accountID, int tongTien, String namePT, String nameCourse, String ngayThanhToan, String ngayMoKhoa, int count, String nameUsser,String trangThai ) {
        this.maHD = maHD;
        this.IDPT = IDPT;
        this.IDCourse = IDCourse;
        this.accountID = accountID;
        this.tongTien = tongTien;
        this.namePT = namePT;
        this.nameCourse = nameCourse;
        this.ngayThanhToan = ngayThanhToan;
        this.ngayMoKhoa = ngayMoKhoa;
        this.count = count;
        this.nameUsser=nameUsser;
        this.trangThai=trangThai;
    }

    public HoaDon(int tongTien, String nameCourse) {
        this.tongTien = tongTien;
        this.nameCourse = nameCourse;
    }

    public HoaDon(int IDPT, int IDCourse, int accountID, int tongTien, String nameUsser, String namePT, String nameCourse, String ngayThanhToan) {
        this.IDPT = IDPT;
        this.IDCourse = IDCourse;
        this.accountID = accountID;
        this.tongTien = tongTien;
        this.nameUsser = nameUsser;
        this.namePT = namePT;
        this.nameCourse = nameCourse;
        this.ngayThanhToan = ngayThanhToan;

    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getNgayMoKhoa() {
        return ngayMoKhoa;
    }

    public void setNgayMoKhoa(String ngayMoKhoa) {
        this.ngayMoKhoa = ngayMoKhoa;
    }

    public int getMaHD() {
        return maHD;
    }

    public void setMaHD(int maHD) {
        this.maHD = maHD;
    }

    public int getIDPT() {
        return IDPT;
    }

    public void setIDPT(int IDPT) {
        this.IDPT = IDPT;
    }

    public int getIDCourse() {
        return IDCourse;
    }

    public void setIDCourse(int IDCourse) {
        this.IDCourse = IDCourse;
    }

    public int getAccountID() {
        return accountID;
    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public int getTongTien() {
        return tongTien;
    }

    public void setTongTien(int tongTien) {
        this.tongTien = tongTien;
    }

    public String getNameUsser() {
        return nameUsser;
    }

    public void setNameUsser(String nameUsser) {
        this.nameUsser = nameUsser;
    }

    public String getNamePT() {
        return namePT;
    }

    public void setNamePT(String namePT) {
        this.namePT = namePT;
    }

    public String getNameCourse() {
        return nameCourse;
    }

    public void setNameCourse(String nameCourse) {
        this.nameCourse = nameCourse;
    }

    public String getNgayThanhToan() {
        return ngayThanhToan;
    }

    public void setNgayThanhToan(String ngayThanhToan) {
        this.ngayThanhToan = ngayThanhToan;
    }
}
