package com.example.assignment_final.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.model.Course;

import java.util.ArrayList;
import java.util.List;


public class DAO_Course {
    private SQLiteDatabase db;
    DbHelper dbHelper;

    public DAO_Course(Context context) {
        dbHelper = new DbHelper( context );
        db = dbHelper.getWritableDatabase();
    }

    public long insert(Course item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "nameCourse", item.getName() );
        values.put( "dateCourse", item.getDate() );
        values.put( "moneyCourse", item.getMoney() );
        values.put( "lesson", item.getCount() );
        return db.insert( "COURSE", null, values );
    }

    public int update(Course item) {
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put( "nameCourse", item.getName() );
        values.put( "dateCourse", item.getDate() );
        values.put( "moneyCourse", item.getMoney() );
        values.put( "lesson", item.getCount() );
        return db.update( "COURSE", values, "courseID=?", new String[]{String.valueOf( item.getID() )} );
    }

    public int delete(String maLoai) {
        db = dbHelper.getWritableDatabase();
        return db.delete( "COURSE", "courseID=?", new String[]{maLoai} );
    }




    public List<Course> get(String sql, String...selectionArgs){
        List<Course> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( sql,selectionArgs );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int IDCourse = Integer.parseInt(c.getString(0));
                String Name = c.getString(1);
                String Date = c.getString(2);
                int Money = c.getInt(3);
                Integer Count = c.getInt(4);
                Course course = new Course(IDCourse, Name, Date, Money, Count);
                list.add(course);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }


    public ArrayList<Course> getAll() {
        ArrayList<Course> list = new ArrayList<>();
        db = dbHelper.getWritableDatabase();
        Cursor c = db.rawQuery( "SELECT * FROM COURSE", null );
        c.moveToFirst();
        while (!c.isAfterLast()){
            try {
                int courseID = Integer.parseInt(c.getString(0));
                String nameCourse = c.getString(1);
                String dateCourse = c.getString(2);
                int moneyCourse = c.getInt(3);
                int lesson = c.getInt(4);
                Course course = new Course(courseID, nameCourse, dateCourse, moneyCourse, lesson);
                list.add(course);
                c.moveToNext();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        c.close();
        return list;
    }

}



