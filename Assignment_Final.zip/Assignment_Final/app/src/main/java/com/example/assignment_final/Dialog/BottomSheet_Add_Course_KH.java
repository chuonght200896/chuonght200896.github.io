package com.example.assignment_final.Dialog;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;



import com.example.assignment_final.Adapter.Adapter_Sp_User_PT;
import com.example.assignment_final.Adapter.Adapter_TOP;
import com.example.assignment_final.DAO.DAO_HoaDon;
import com.example.assignment_final.DAO.DAO_PT;
import com.example.assignment_final.DAO.DAO_Schedule;
import com.example.assignment_final.Database.DbHelper;
import com.example.assignment_final.R;
import com.example.assignment_final.model.HoaDon;
import com.example.assignment_final.model.PT;
import com.example.assignment_final.model.Schedule;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;


import static com.example.assignment_final.fragment.Fragment_Activity_Home_User.rcvTOPActivityUser;


public class BottomSheet_Add_Course_KH extends BottomSheetDialogFragment {
    TextView tvTenKhoaHoc,tvNgayMoKhoa,tvCount,tvNotifi;
    Spinner spPT;
    Button btnUp;
    EditText tvTien;
    ArrayList<PT> ds_PT;
    DAO_PT dao_pt;
    Adapter_Sp_User_PT adapter_sp_user_pt;
    DAO_HoaDon dao_hoaDon;
    HoaDon hoaDon;
    DbHelper dbHelper;
    DAO_Schedule dao_schedule;
    Adapter_TOP top_adapter;
    Schedule schedule;
    public  String dateSchedule;
    public int id;
    public ArrayList<HoaDon> list_HoaDon;
    public ArrayList<Schedule> list_Schedule;
    public int idCourse;
    public int hourStart;
    public int hourEnd;
    public String hour;
    public Random random = new Random();
    public BottomSheet_Add_Course_KH(){
    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view   = inflater.inflate( R.layout.bottom_sheet_edit_user_course,container,false );
        tvTenKhoaHoc  = view.findViewById( R.id.tvTenKhoaHocBot  );
        tvTien  = view.findViewById( R.id.tvTienBot );
        tvNgayMoKhoa  = view.findViewById( R.id.tvNgayMoKhoaBot );
        tvCount  = view.findViewById( R.id.tvCountBot );
        btnUp  = view.findViewById( R.id.btnAdd );
        spPT  = view.findViewById( R.id.spPTBot );
        tvNotifi=view.findViewById( R.id.tvNotifi ) ;
        Bundle bundle =getArguments();
        idCourse =  bundle.getInt( "ID" );
        final String TenKhoaHoc = bundle.getString( "TenKhoaHoc" );
        final int Tien = bundle.getInt( "Tien" );
        final String NgayMoKhoa = bundle.getString( "NgayMoHoc" );
        int Count = bundle.getInt( "Count" );

        final DecimalFormat decimalFormat= (DecimalFormat) NumberFormat.getInstance( Locale.US);
        decimalFormat.applyPattern( "#,###,###,###" );
        final String[] formattedString = {decimalFormat.format( Tien )};

        final int[] Money = new int[1];
        tvTenKhoaHoc.setText( TenKhoaHoc);
        tvTien.setText( formattedString[0] +" USD");
        tvTien.addTextChangedListener( onTextChangedListener() );
        tvNgayMoKhoa.setText( NgayMoKhoa);
        tvCount.setText( Count +"" );

        final int[] IDPT = {0};
        ds_PT = new ArrayList<>(  );
        dao_pt = new DAO_PT( getContext() );

        ds_PT = (ArrayList<PT>) dao_pt.getAll();
        adapter_sp_user_pt= new Adapter_Sp_User_PT( getContext(),ds_PT );
        spPT.setAdapter( adapter_sp_user_pt );

        dbHelper = new DbHelper( getContext() );
        spPT.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                for( int j=0;j<ds_PT.size();j++){
                    if(adapterView.getItemAtPosition( i ).toString().equalsIgnoreCase( ds_PT.get( j ).getName().toString() )){
                        Money[0] = Tien + ds_PT.get( j ).getMoney() ;
                        formattedString[0] =decimalFormat.format( Money[0] );
                        tvTien.setText(formattedString[0] +" USD"  );
                        IDPT[0] = ds_PT.get( j ).getID();
//                        Toast.makeText( getContext(), ""+adapterView.getItemAtPosition( i ).toString(), Toast.LENGTH_SHORT ).show();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        } );

        Date today= new Date(  );
        SimpleDateFormat simpleDateFormat= new SimpleDateFormat( "yyyy/MM/dd" );
        String date = simpleDateFormat.format( today );

        dao_schedule = new DAO_Schedule( getContext() );
        list_Schedule= dao_schedule.getScheduleByIDCourse( idCourse );
        if(list_Schedule.get( 0 ).getDateSchedule().compareTo( date )<0){
            btnUp.setEnabled( false );
            btnUp.setBackgroundColor( Color.parseColor("#808080"));
            tvNotifi.setTextColor( Color.parseColor("#0000FF"));
            tvNotifi.setText("*********XIN LỖI! KHÓA HỌC ĐÃ ĐÓNG!********" );
            @SuppressLint("ResourceType") Animation animation = AnimationUtils.loadAnimation(getActivity(),R.anim.animal);
            tvNotifi.startAnimation(animation);
        }


        btnUp.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
                String date = df.format( Calendar.getInstance().getTime());

                dao_hoaDon= new DAO_HoaDon( getContext() );
                hoaDon = new HoaDon(IDPT[0],idCourse,dbHelper.IDuser ,Money[0],dbHelper.Username,spPT.getSelectedItem().toString(),TenKhoaHoc,date );
                dao_hoaDon.insert( hoaDon );
                Toast.makeText( getContext(), "Đăng ký thành công", Toast.LENGTH_SHORT ).show();
                capNhat();

                dismiss();
            }
        } );
        return view;
    }
    public  void capNhat(){
        ds_PT= dao_pt.getTOP_PT();
        top_adapter= new Adapter_TOP( ds_PT,getContext() );
        rcvTOPActivityUser.setAdapter(top_adapter);
        top_adapter.notifyDataSetChanged();
    }
    //
    private TextWatcher onTextChangedListener() {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                tvTien.removeTextChangedListener(this);

                try {
                    String originalString = s.toString();

                    Long longval;
                    if (originalString.contains(",")) {
                        originalString = originalString.replaceAll(",", "");
                    }
                    longval = Long.parseLong(originalString);

                    DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
                    formatter.applyPattern("#,###,###,###");
                    String formattedString = formatter.format(longval);

                    //setting text after format to EditText
                    tvTien.setText(formattedString);
                    tvTien.setSelection(tvTien.getText().length());
                } catch (NumberFormatException nfe) {
                    nfe.printStackTrace();
                }

                tvTien.addTextChangedListener(this);
            }
        };
    }

}
