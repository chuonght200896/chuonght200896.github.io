package com.example.assignment_final.Activity;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.assignment_final.R;
import com.example.assignment_final.fragment.Fragment_Activity_Home_User;
import com.example.assignment_final.fragment.Fragment_User_News;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Activity_User extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_user );
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation_user);
        if (savedInstanceState == null){
            loadFragment(new Fragment_Activity_Home_User());
        }
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment;
                switch (item.getItemId()) {
                    case R.id.botHome:
                        fragment = new Fragment_Activity_Home_User();
                        loadFragment(fragment);
                        break;
                    case R.id.botNews:
                        fragment = new Fragment_User_News();
                        loadFragment(fragment);
                        break;
                }
                return false;
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = this.getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(
                        android.R.anim.slide_in_left,  // enter
                        R.anim.fadeout,  // exit
                        R.anim.fadein,   // popEnter
                        android.R.anim.slide_out_right); // popExit
        transaction.replace(R.id.fr_, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
    @Override
    public void onBackPressed() {
        finish();
    }


}

